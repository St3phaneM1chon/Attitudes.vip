# CLAUDE.md - Mémoire Persistante du Projet Attitudes.vip

## 🤖 AUTO-VÉRIFICATION MCP - TOUJOURS ACTIF

**IMPORTANT**: Avant CHAQUE action, exécuter mentalement :
```javascript
const mcpCheck = await checkMCP(userRequest);
if (mcpCheck.shouldUseMCP) {
  // Utiliser les services MCP recommandés
  console.log(mcpCheck.actionPlan);
}
```

### Services MCP Disponibles
- ✅ **filesystem** - Opérations fichiers/répertoires
- ✅ **postgres** - Requêtes base de données  
- ✅ **redis** - Cache et sessions
- ✅ **git** - Contrôle de version
- ⏳ **stripe** - Paiements (à configurer)
- ⏳ **twilio** - SMS (à configurer)
- ⏳ **memory** - Mémoire persistante (à installer)

## 🎯 Contexte du Projet

**Projet**: Attitudes.vip - Plateforme SaaS de gestion de mariages
**Type**: Application web multi-tenant, multilingue
**Stack**: Node.js, PostgreSQL, Redis, Docker, Kubernetes
**État**: En développement (40% complété)

## 📊 Architecture Technique Clé

### Services Principaux
- **Auth Service**: OAuth2 multi-providers (Google, Facebook, Twitter, Apple)
- **Database**: PostgreSQL 15 via Supabase
- **Cache**: Redis 7
- **API Gateway**: Nginx
- **Container**: Docker Compose / Kubernetes

### Dashboards par Rôle (13 types)
1. CIO - `/dashboard/cio` - Accès total
2. Admin - `/dashboard/admin` - Support Attitudes.vip
3. Client - `/dashboard/client` - Marque blanche
4. Customer - `/dashboard/customer` - Couples mariés
5. Invite - `/dashboard/invite` - Invités
6. DJ - `/dashboard/dj` - Animation
7. Wedding Planner - `/dashboard/wedding-planner`
8. Photographe - `/dashboard/photographe`
9. Traiteur - `/dashboard/traiteur`
10. Pâtissier - `/dashboard/patissier`
11. Location - `/dashboard/location`

## 🔧 Commandes Essentielles

```bash
# Développement
npm install              # Installer dépendances
npm run dev             # Lancer en mode dev
npm run lint            # Vérifier le code
npm run typecheck       # Vérifier les types
npm test                # Lancer les tests

# Docker
docker-compose up -d    # Lancer tous les services
docker-compose down     # Arrêter les services
docker-compose logs -f  # Voir les logs

# Base de données
npm run db:init         # Initialiser la DB
npm run db:migrate      # Migrations
npm run db:seed         # Données de test

# Déploiement
./scripts/deploy.sh     # Déployer en production
./scripts/health-check.sh # Vérifier santé système
```

## 📁 Structure Importante

```
/src/
├── auth/           # Authentification OAuth2/JWT
├── dashboards/     # UI par type utilisateur
├── services/       # Logique métier
├── i18n/          # 100+ langues
└── styles/        # Tailwind CSS

/ops/kubernetes/    # Config K8s, Zero Trust
/supabase/         # Backend config
/docs/             # Documentation complète
```

## 🌍 Spécificités Régionales

### 9 Régions Supportées
- Amérique du Nord, Europe, Moyen-Orient
- Asie, Afrique, Amérique Latine
- Caraïbes, Océanie, Océan Indien

### 6 Religions Adaptées
- Adaptations culturelles pour cérémonies
- Restrictions alimentaires
- Musiques et décorations appropriées

## 🔐 Sécurité - Standards Enterprise

### Implémentés
- JWT avec refresh tokens (24h)
- Bcrypt 12 rounds
- Rate limiting (100/15min)
- Helmet.js headers
- CORS strict
- Network policies K8s

### À Implémenter
- [ ] WAF (Web Application Firewall)
- [ ] DDoS protection
- [ ] Secrets management (Vault)
- [ ] Compliance scanning
- [ ] Penetration testing

## 📝 État Actuel et Priorités

### Complété ✅
1. Architecture de base
2. Service authentification
3. Configuration infrastructure
4. Documentation technique

### En Cours 🚧
1. Dashboard Customer UI
2. Intégration WebSockets
3. Service notifications

### Priorité Haute 🔴
1. Finaliser auth flow complet
2. Dashboard Customer fonctionnel
3. Service paiement Stripe
4. Tests automatisés

### Prochaines Étapes
1. Implémenter UI Tailwind complète
2. Services temps réel (Socket.io)
3. Intégrations externes (SMS, Email)
4. CI/CD pipeline

## 💡 Patterns et Conventions

### Code
- Async/await privilégié
- Error handling centralisé
- Logging avec Winston
- Tests Jest (80% coverage min)

### Git
- Branches: feature/*, bugfix/*
- Commits: type(scope): message
- PR obligatoires avec review

### API
- RESTful standards
- Versioning: /api/v1/
- JSON responses
- HTTP status codes standards

## 🚨 Points d'Attention

1. **Multi-tenancy**: Isolation stricte données clients
2. **Performance**: Cache Redis obligatoire
3. **i18n**: Toujours utiliser clés traduction
4. **Sécurité**: Jamais de secrets en code
5. **Tests**: Aucun merge sans tests

## 📊 Métriques Cibles

- Temps réponse API: < 200ms
- Uptime: 99.9%
- Concurrent users: 10k
- Page load: < 3s
- Test coverage: > 80%

## 🔗 Ressources Rapides

- Supabase Dashboard: [À configurer]
- Monitoring: Prometheus + Grafana
- Logs: Fluentd aggregation
- CI/CD: GitHub Actions
- Staging: [À déployer]

## 🎯 Vision Produit

Devenir LA plateforme mondiale de gestion de mariages, culturellement adaptée, avec expérience utilisateur exceptionnelle pour tous les acteurs d'un mariage, du couple aux fournisseurs.

---
*Ce fichier sert de mémoire persistante pour Claude. Mettre à jour régulièrement avec les changements importants du projet.*